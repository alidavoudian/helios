aclocal
#libtoolize
autoconf
automake --add-missing
#make clean
./configure CXXFLAGS="-g -O0" #CXX=mpicxx
