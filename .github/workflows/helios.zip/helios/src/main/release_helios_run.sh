cp helios_server /usr/data/helios_test/hrun/
#cp ../redis-module-helios/heliosmodule.so /usr/data/helios_test/run_helios/
cp helios.cfg /usr/data/helios_test/run_helios/
#cp machineFile /usr/data/chenliu/svn_helios/run_helios/
#cp dataDir /usr/data/chenliu/svn_helios/run_helios/
#cp dictDir /usr/data/chenliu/svn_helios/run_helios/
#cp machinefile /usr/data/chenliu/svn_helios/run_helios/
