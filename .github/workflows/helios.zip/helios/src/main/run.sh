cd ../../
#./init.sh
make 
#g++ -g -gdwarf-2 -O0  -o src/loader/loader src/database/libdatabase.a src/utils/libutils.a src/loader/libloader.a -lmpi -lhiredis -lpthread -lconfig++ 
